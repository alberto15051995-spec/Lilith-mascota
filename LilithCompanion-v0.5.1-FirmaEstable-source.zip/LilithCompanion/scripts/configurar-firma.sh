#!/usr/bin/env bash
set -euo pipefail

# Configuración una sola vez de la firma estable.
# Los secretos no se imprimen ni se guardan en el repositorio.
if ! command -v keytool >/dev/null 2>&1; then
  echo "Falta keytool. Usa Codespaces con Java 17." >&2; exit 1
fi
if ! command -v gh >/dev/null 2>&1; then
  echo "Falta GitHub CLI (gh)." >&2; exit 1
fi
if ! gh auth status >/dev/null 2>&1; then
  echo "GitHub CLI necesita iniciar sesión. Ejecuta: gh auth login" >&2; exit 1
fi
repo="$(gh repo view --json nameWithOwner --jq .nameWithOwner)" || {
  echo "No puedo identificar el repositorio. Abre Codespaces dentro de Lilith-mascota." >&2; exit 1;
}
if [[ "$repo" != */Lilith-mascota ]]; then
  echo "Repositorio inesperado: $repo. Esta configuración es solo para Lilith-mascota." >&2; exit 1
fi
mkdir -p ".signing"
chmod 700 ".signing"
keystore="$(pwd)/.signing/lilith-release.jks"
if [[ -e "$keystore" ]]; then
  echo "Ya existe una clave en $keystore. NO generes otra: cambiaría la firma." >&2
  echo "Si necesitas reconfigurar secretos, utiliza primero la clave guardada." >&2
  exit 1
fi
printf 'Creando firma estable para %s\n' "$repo"
read -r -s -p 'Crea una contraseña larga (mínimo 12 caracteres): ' password; echo
if (( ${#password} < 12 )); then echo "Contraseña demasiado corta" >&2; exit 1; fi
read -r -s -p 'Repite la contraseña: ' confirmation; echo
if [[ "$password" != "$confirmation" ]]; then echo "No coinciden" >&2; exit 1; fi
unset confirmation
alias_name='lilithcompanion'
# -storetype PKCS12 genera un archivo firmado, independiente de la extensión .jks.
# Conservamos .jks por compatibilidad con configuraciones anteriores.
keytool -genkeypair -noprompt -alias "$alias_name" -keyalg RSA -keysize 3072 \
  -validity 10000 -dname 'CN=Lilith Companion, OU=Personal, O=Lilith' \
  -keystore "$keystore" -storetype PKCS12 -storepass "$password" -keypass "$password" >/dev/null
chmod 600 "$keystore"
# Usa stdin y no publica el archivo ni el secreto en git.
base64 -w 0 "$keystore" | gh secret set LILITH_KEYSTORE_BASE64 --repo "$repo"
printf '%s' "$password" | gh secret set LILITH_STORE_PASSWORD --repo "$repo"
printf '%s' "$password" | gh secret set LILITH_KEY_PASSWORD --repo "$repo"
printf '%s' "$alias_name" | gh secret set LILITH_KEY_ALIAS --repo "$repo"
unset password
printf '\nFirma configurada para GitHub Actions.\n'
printf 'RESPALDO OBLIGATORIO: %s\n' "$keystore"
printf 'Descarga este archivo a un lugar privado, junto con la contraseña.\n'
printf 'Los GitHub Secrets NO permiten recuperar el JKS si pierdes esta copia.\n'
printf 'No subas el JKS ni su Base64 al repositorio o al chat.\n'
